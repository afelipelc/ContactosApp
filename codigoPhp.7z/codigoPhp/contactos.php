<?php
/*
* Servicio web que sirve distintos m�todos para gestionar la lista de contactos que se
* encuentra registrada en la BD
*
* Este proyecto requiere Zend Framework, la versi�n utilizada fue la v1.12.0
*
*/

// Agregamos la ra�z al path para los require_once
set_include_path(get_include_path() .
                 PATH_SEPARATOR .
                 realpath(dirname(__FILE__) . "/../"));

require_once('ws\clases\Contacto.php');
require_once('Zend\Db\Adapter\Pdo\Mysql.php');

//archivo que sirve la lista de contactos en nuestro servidor
class ContactosWS
{
	private $db;
	
	function __construct() {
		$this->db = new Zend_Db_Adapter_Pdo_Mysql(array(
		'host'     => '127.0.0.1',
		'username' => 'root',
		'password' => 'afelipelc1',
		'dbname'   => 'tallerandroid'
		));
		$this->db->setFetchMode(Zend_Db::FETCH_OBJ);
	}
	/**
	 * Devuelve la lista de todos los contactos registrados
	 *
	 * @return array
	*/
	function Lista()
	{
		$sql = 'SELECT * FROM contactos';
		$result = $this->db->fetchAll($sql);
		return $result;
	}
	
	/**
	 * Devuelve los datos del contacto especificado
	 * 
	 * @param int
	 * @return Contacto
	*/
	function DatosContacto($idContacto)
	{
		$sql = "SELECT * FROM contactos where id=$idContacto limit 1";
		$result = $this->db->fetchRow($sql);
		return $result;
	}
	
	/**
	 * Registra un nuevo contacto
	 *
	 * @param string
	 * @param string
	 * @param string
	 * @param string
	 * @return Contacto
	*/
	function RegistrarContacto($nombre, $apellidos, $email, $telefono)
	{
		if($nombre != null && $apellidos!="")
		{
			$data = array('nombre' => "$nombre",'apellidos' => "$apellidos", 'email'=> "$email", 'telefono'=>"$telefono");
			$this->db->insert('contactos', $data);
			$id = $this->db->lastInsertId();
			$sql = "SELECT * FROM contactos where id= $id";
			$result = $this->db->fetchRow($sql);
			return $result;
		}else
			return null;
	}
	
	/**
	 * Actualizar un contacto
	 *
	 * @param integer
	 * @param string
	 * @param string
	 * @param string
	 * @param string
	 * @return boolean
	*/
	function ActualizarContacto($id, $nombre, $apellidos, $email, $telefono)
	{
		if($id!=null && $id!=0 &&$nombre != null && $apellidos!="")
		{

			$data = array('nombre' => "$nombre",'apellidos' => "$apellidos", 'email'=> "$email", 'telefono'=>"$telefono");
			$this->db->update('contactos', $data, "id = $id");
			
			return true;
		}else
			return false;
	}

	/**
	 * Devuelve la lista de todos los que coincidan con la busqueda
	 *
	 * @param string
	 * @return array
	*/
	function Buscar($q)
	{
		$sql = "SELECT * FROM contactos where nombre like '%$q%' or apellidos like '%$q%'";
		$result = $this->db->fetchAll($sql);
		return $result;
	}
	
	/**
	 * Devuelve el numero total de contactos registrados
	 *
	 * @return integer
	*/
	function Total(){
		$sql = 'SELECT * FROM contactos';
		$result = $this->db->fetchAll($sql);
		return count($result);
	}
}
?>
