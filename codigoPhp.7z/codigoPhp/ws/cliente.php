<?php
// Agregamos la ra�z al path para que podamos
// incluir Zend de forma directa
set_include_path(get_include_path() .
                 PATH_SEPARATOR .
                 realpath(dirname(__FILE__) . "/../"));

//---------------------------------------------------------------
// Creamos un cliente soap
//---------------------------------------------------------------
require_once("Zend/Soap/Client.php");
$wsdl_url = "http://localhost/ws/servidor.php?wsdl";
$SOAP_1_2;
$cliente = new Zend_Soap_Client($wsdl_url,array('encoding'=>'ISO-8859-1'));

//---------------------------------------------------------------
// Saludamos en varios idiomas
//---------------------------------------------------------------
echo "<h1>Metodo Lista</h1>";

	//$contactos =  $cliente->Lista();
	echo $cliente->Total();
	
	
	foreach($cliente->Lista() as $contacto)
	{
		echo $contacto->nombre;
		echo "<br/>";
	}
	
	foreach($cliente->Buscar('felipe') as $contacto)
	{
		echo "Encontrado>> ".$contacto->nombre;
		echo "<br/>";
	}
	


?>