<?php
//namespace ws;

//use ws\clases\Contacto;

// Agregamos la ra�z al path para los require_once
set_include_path(get_include_path() .
                 PATH_SEPARATOR .
                 realpath(dirname(__FILE__) . "/../"));

require_once('clases\Contacto.php');
require_once('..\Zend\Db\Adapter\Pdo\Mysql.php');



//archivo que sirve la lista de contactos en nuestro servidor
class ContactosWS
{

private $db;

function __construct() {
	$db = new Zend_Db_Adapter_Pdo_Mysql(array(
    'host'     => '127.0.0.1',
    'username' => 'root',
    'password' => 'afelipelc1',
    'dbname'   => 'tallerandroid'
));
$db->setFetchMode(Zend_Db::FETCH_OBJ);
}
	/**
	 * Devuelve la lista de todos los contactos registrados
	 *
	*/
	function Lista()
	{
		$sql = 'SELECT * FROM contactos';
		$result = $db->fetchAll($sql);
		return $result;
	}
	
	function Total(){
		$sql = 'SELECT * FROM contactos';
		$result = $db->fetchAll($sql);
		return count($result);
	}
}
/*

$persona1 = new Contacto();
$persona1->id=1;
$persona1->nombre="Felipe";

echo $persona1->id." .- ".$persona1->nombre;
echo "<br>";



//By default, fetchAll() returns an array of rows
//Zend_Db::FETCH_ASSOC: return data in an array of associative arrays

//select


$sql = 'SELECT * FROM contactos';
 
$result = $db->fetchAll($sql);

echo  count($result)."<br>registros<br>";

$contactos = Array();
$contactos=$result;
echo  count($contactos)."---registros<br>";

/*
foreach ($result AS $row) {
	//echo $row->nombre;
	$personax = new Contacto();
	$personax = $row;
	
	echo $personax->nombre.", id: ".$personax->id."<br>";
}
*/
/*
foreach ($contactos AS $contacto) {
	//echo $row->nombre;
	//$contactox = new Contacto();
	//$contactox = $contacto;
	
	echo $contacto->nombre.", id: ".$contacto->id."<br>";
}
*/
/*

//insert
$data = array(
    'nombre'      => 'Juan',
    'apellidos' => 'P�rez',
    'email'      => 'perez@serv.com',
	'tel'	=> '456476'
);
$db->insert('contactos', $data);

//update
$data = array(
    'nombre'      => 'A. Felipe'
);
$n = $db->update('contactos', $data, 'id = 1');

//delete
//$n = $db->delete('tabla', 'pk = int-val');

*/

?>
