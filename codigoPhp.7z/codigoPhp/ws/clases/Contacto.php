<?php
//namespace ws\clases;

//-----------------------------
/*
*Clase Persona que contiene los atributos especificados en el esquema de la tabla tallerandroid.contactos
*/
class Contacto
{
	/** @var integer */
	public $id;
	
	/** @var string */
	public $nombre;
	
	/** @var string */
	public $apellidos;
	
	/** @var string */
	public $email;
	
	/** @var string */
	public $telefono;
}


?>