<?php
// Agregamos la ra�z al path para los require_once
set_include_path(get_include_path() .
                 PATH_SEPARATOR .
                 realpath(dirname(__FILE__) . "/../"));

				 
// Incluimos nuestra clase que tiene el servicio web
require_once('contactos.php');

if ($_SERVER['QUERY_STRING'] == 'wsdl')
{
	// Utilizamos la clase Zend_Soap_AutoDiscover para
	// generar de forma autom�tica el WSDL
	require_once('Zend/Soap/AutoDiscover.php');
	$wsdl = new Zend_Soap_AutoDiscover();
	$wsdl->setClass('ContactosWS');
	$wsdl->handle();
}
else
{
	// Calculamos la ruta del WSDL del servidor
	$wsdl_url = sprintf('http://%s%s?wsdl', $_SERVER['HTTP_HOST'], $_SERVER['SCRIPT_NAME']);    

	// Creamos un servidor que atienda en base al WSDL generado
	require_once('Zend/Soap/Server.php');
	$server = new SoapServer($wsdl_url,array('encoding'=>'ISO-8859-1'));
	$server->setClass('ContactosWS');
	$server->handle();
}
?>