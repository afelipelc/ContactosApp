--
-- Base de datos: `tallerandroid`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contactos`
--

CREATE TABLE IF NOT EXISTS `contactos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(24) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=6 ;

--
-- Volcado de datos para la tabla `contactos`
--

INSERT INTO `contactos` (`id`, `nombre`, `apellidos`, `email`, `telefono`) VALUES
(1, 'Felipe', 'L', 'afelipelc@gmail.com', '1231'),
(2, 'Juan', 'Pérez', 'perez@serv.com', '456476'),
(3, 'Pepe', 'Montes', 'pepmon@serv.com', '765432'),
(4, 'pepe', 'm.', 'mj@ad.m', '587425'),
(5, 'Benito', 'Pérez', 'benis@serv.mx', '12545875');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
